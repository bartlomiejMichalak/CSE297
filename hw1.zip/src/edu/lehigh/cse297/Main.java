/* CSE 297 - Fall 2013
 * Homework #1 - Mini HTTP Server
 * Name: Bartlomiej (Bart) Michalak
 * Date: Sept. 4, 2013
 * Bpm215
 */
package edu.lehigh.cse297;

import java.io.*;
import java.net.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Main {
    // The port can be any small integer that isn't being used by another program
    private static final int port = 8567;

    public static void main(String[] args) {
        try {
            System.out.println("Mini HTTP Server Starting Up");
            // Listen on port for a new connection request
            
            ServerSocket s = new ServerSocket(port);
            for (;;) {
                // Wait for a new TCP connection to come in from a client and 
                // accept it when it does. Return a reference to the socket 
                // that will be used to communicate with the client.
                Socket newSocket = s.accept();
               // System.out.println("New connection from: " + ((InetSocketAddress)newSocket.getRemoteSocketAddress()).getAddress().getHostAddress());
                String myIP = ((InetSocketAddress)newSocket.getRemoteSocketAddress()).getAddress().getHostAddress();
                // Create a new handler object to handle the requests of the 
                // client that just connected.
                ClientHandler handler = new ClientHandler(newSocket, myIP);
                // Give the handler its own thread to handle requests to that 
                // the server can handle multiple clients simultaneously.
                new Thread(handler).start();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

class ClientHandler implements Runnable {
    // Socket used to handle the client requests.
    private Socket socket;
    private String myPath;
    private String myIP;
    private int responseCode;
    public ClientHandler(Socket s, String myIP) {
        this.socket = s;
        this.myIP = myIP;
    }

    @Override
    public void run() {
        
        try {
            BufferedReader request = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            DataOutputStream response = new DataOutputStream(socket.getOutputStream());
            List<String> headers = new ArrayList<>();
            PrintWriter log = new PrintWriter(new BufferedWriter(new FileWriter("access.log", true)));

            try {
                String firstLine = request.readLine();
                if (firstLine.length() > 0) {
                    // Read Headers
                    String line;
                    while ((line = request.readLine()).length() > 0) {
                        headers.add(line);
                    }
                    String[] tokens = firstLine.split(" ");
                    String method = tokens[0];
                    String resource = tokens[1];
                    dumpRequest(firstLine, headers);
                    switch (method) {
                        case "GET":
                            responseCode = processGET(resource, headers, response);
                            
                            break;
                        case "POST":
                            System.err.println(method + " method not implemented.");
                            break;
                        case "HEAD":
                            System.err.println(method + " method not implemented.");
                            break;
                        case "PUT":
                            System.err.println(method + " method not implemented.");
                            break;
                        case "DELETE":
                            System.err.println(method + " method not implemented.");
                            break;
                        case "TRACE":
                            System.err.println(method + " method not implemented.");
                            break;
                        case "OPTIONS":
                            System.err.println(method + " method not implemented.");
                            break;
                        default:
                            System.err.println("Unknown method: " + method);
                            break;
                            
                    }
                }
            } catch (Exception e) {
                response.writeBytes("HTTP/1.1 404 ERROR\n\n");
            }
            log.println(myIP + " " + myPath + " " + responseCode);
            log.println(System.getProperty("line.separator"));
            log.flush();
            log.close();
            request.close();
            response.close();
        } catch (Exception ex1) {
            System.out.println("Internal error: " + ex1.getMessage());
        }
    }

    // Write out the request header lines to the console
    private void dumpRequest(String firstLine, List<String> headers) {
        System.out.println(firstLine);
        for (String headerLine : headers) {
            System.out.println(headerLine);
        }
        System.out.println();
    }

    private int processGET(String resource, List<String> headers, DataOutputStream out) {
        try {

            // Default to index.html
            if (resource.endsWith("/")) {
                resource += "index.html";
            }

            // Create file path from requested resource compatable with the host OS
            myPath = ("." + resource).replace('/', File.separatorChar);
            int length = (int) new File(myPath).length();
            byte[] b = new byte[length];

            // Read in requested resource
            FileInputStream resourceStream;
            try {
                resourceStream = new FileInputStream(myPath);
                resourceStream.read(b);
            } catch (IOException ex) {
                out.writeBytes("HTTP/1.1 404 ERROR\n\n");
                return 404;
            }

            SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyy");
            String dt = sdf.format(new Date());
            
            // Write HTTP response to client
            out.writeBytes("HTTP/1.1 200 OK\n");
            out.writeBytes("Content-Length:" + length + "\n");
            out.writeBytes("Date of Request: "+sdf+"\n");
            out.writeBytes("Name of Server is: Bart's Java Server");
            out.writeBytes("Connection: close\n");
            out.writeBytes("\n"); // Blank line ends the header section
            out.write(b, 0, length); // Send the requested resource to the client
            return 200;
        } catch (IOException ex) {
            try {
                out.writeBytes("HTTP/1.1 500 ERROR\n\n");
                return 500;
            } catch (IOException ex1) {
                System.out.println("Internal error: " + ex1.getMessage());
                return 500;
            }
        }
    }
}